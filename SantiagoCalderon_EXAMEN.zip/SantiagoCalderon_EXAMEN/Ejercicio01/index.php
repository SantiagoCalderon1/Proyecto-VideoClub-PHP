<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 01 - Area de tres conos</title>
</head>

<body>
    <h1>ÁREA DE LOS CONOS</h1>
    <?php
    
    define('PI', 3.1416);

    $cono1 = [
        'radio' => 3,
        'altura' => 15,
        'area' => PI * pow(3, 2) * (sqrt(pow(3, 2) + pow(15, 2)) )
    ];

    $cono2 = [
        'radio' => 8,
        'altura' => 21,
        'area' => PI * pow(8, 2) * (sqrt(pow(8, 2) + pow(21, 2)) )
    ];

    $cono3 = [
        'radio' => 9.5,
        'altura' => 6,
        'area' => PI * pow(9.5, 2) * (sqrt(pow(9.5, 2) + pow(6, 2)) )
    ];

    $conos = [
        'cono1' => $cono1,
        'cono2' => $cono2,
        'cono3' => $cono3
    ];

    foreach ($conos as $key => $value) {
        echo "<p>El área del cono $key (radio: " . $value['radio'] . ", altura: " . $value['altura'] . "): " . $value['area']."</p>";
    }




    ?>


</body>

</html>